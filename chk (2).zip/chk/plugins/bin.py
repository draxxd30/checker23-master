import json
import requests
import time
import asyncio
from plugins.clases.usuarios import usuario

from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import (
   Message,
   InlineKeyboardButton,
   InlineKeyboardMarkup,
   )


@Client.on_message(filters.command(["bin"], prefixes=["/", "."]))
async def bin(_, m: Message):
    username = m.from_user.username
    id = m.from_user.id
    user = usuario(username, id)
    datos = user.buscar()
    if not datos or datos == False: return await m.reply('<b>Usuario no registrado porvafor registrese con /start</b>')
    
    BIN = m.text[len("/bin "): 11]
    
    if len(BIN) < 6:
        return await m.reply("❌ 𝐏𝐥𝐞𝐚𝐬𝐞 𝐞𝐧𝐭𝐞𝐫 𝐚 𝐯𝐚𝐥𝐢𝐝 𝐁𝐢𝐧")
    if not BIN:
       return await m.reply("❌ 𝐏𝐥𝐞𝐚𝐬𝐞 𝐞𝐧𝐭𝐞𝐫 𝐚 𝐯𝐚𝐥𝐢𝐝 𝐁𝐢𝐧")

    inputm = m.text.split(None, 1)[1]
    bincode = 6

    BIN = inputm[:bincode]

    gateBIN = requests.get(f"https://bins-su-ani.vercel.app/api/{BIN}").json()
    if gateBIN["result"] == True:
        status = "𝐕𝐚𝐥𝐢𝐝 𝐁𝐢𝐧"
        bin = gateBIN["data"]["bin"]
        vendor = gateBIN["data"]["vendor"]
        type = gateBIN["data"]["type"]
        level = gateBIN["data"]["level"]
        bank = gateBIN["data"]["bank"]
        codeCountry = gateBIN["data"]["countryInfo"]["code"]
        country = gateBIN["data"]["countryInfo"]["name"]
        emojiCountry = gateBIN["data"]["countryInfo"]["emoji"]
    

        
        
        resultados = (f"""
✅ {status}
↯ 𝐁𝐢𝐧: <b><code>{bin}</code></b>
↯ 𝐈𝐧𝐟𝐨: <code>{vendor} - {type} - {level}</code>
↯ 𝐁𝐚𝐧𝐤: <code>{bank}</code> 
↯ 𝐂𝐨𝐮𝐧𝐭𝐫𝐲: <code>{country}</code> -{emojiCountry}
↯ 𝐎𝐰𝐧𝐞𝐫: <code><i>Draxxd30</i></code>
""")

        
        return await m.reply(resultados)
    else:
        return await m.reply("❌ 𝐏𝐥𝐞𝐚𝐬𝐞 𝐞𝐧𝐭𝐞𝐫 𝐚 𝐯𝐚𝐥𝐢𝐝 𝐁𝐢𝐧")

