import requests
def buscarEnT(res, primer, final):
    try:
        inicio = res.index( primer ) + len( primer )
        fin = res.index( final, inicio )
        return res[inicio:fin]
    except ValueError:
        return None
    
def get_cc(t): 
    t1 = t.replace("|", " ")
    t = t1.replace("/", " ")
    list = str.split(t)
    cc, mes, año, cvv = "", "", "", ""
    for parte in list:
        try:
            if parte.isdigit():
                if len(parte) == 16: cc = parte
                elif len(parte) == 1 or len(parte) == 2: 
                    if parte[0] == "1" or parte[0] == "0": mes = parte
                    elif parte[0] == "2": año = parte
                elif len(parte) == 4: 
                    if parte[0] == "2": año = parte
                elif len(parte) == 3: cvv = parte
        except: continue
    #texto = f"{cc}|{mes}|{año}|{cvv}"
    return cc, mes, año, cvv
def luhn(Card):
    Numeros = list(map(int, Card))
    n1 = sum(Numeros[-1::-2]) #Suma de pares
    n2 = sum([sum(divmod(2 * l, 10)) for l in Numeros[-2::-2]]) #Numeros impares
    rest = (n1 + n2) % 10 #resto de division de la suma
    if rest == 0: return True
    else: return False
def bininfo(cc):
    BIN = cc[:6]
    gateBIN = requests.get(f"https://bins-su-ani.vercel.app/api/{BIN}").json()
    try:
        bin = gateBIN["data"]["bin"]
        vendor = gateBIN["data"]["vendor"]
        tipo = gateBIN["data"]["type"]
        level = gateBIN["data"]["level"]
        bank = gateBIN["data"]["bank"]
        codeCountry = gateBIN["data"]["countryInfo"]["code"]
        country = gateBIN["data"]["countryInfo"]["name"]
        emojiCountry = gateBIN["data"]["countryInfo"]["emoji"]
        if bank == "":
            bank = "/"
        elif vendor == "":
            vendor = "/"
        elif tipo == "":
            tipo = "/"
        elif level == "":
            level = "/"
        elif codeCountry == "":
            codeCountry = "/"
        elif country == "":
            country = "/"
        elif emojiCountry == "":
            emojiCountry = "/"
        return bin, vendor, tipo, level, bank, codeCountry, country, emojiCountry
    except Exception as a:
        return